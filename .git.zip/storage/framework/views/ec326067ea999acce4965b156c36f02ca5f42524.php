

<?php $__env->startSection('custom_css'); ?>

  <!-- CSS Plugin TimePicker -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-timepicker/0.5.2/css/bootstrap-timepicker.min.css" rel="stylesheet">

  <!-- CSS Plugin DatePicker Material -->
  <link href="<?php echo e(URL::asset('assets/js/datepicker_material/css/bootstrap-material-datetimepicker.css')); ?>" rel="stylesheet">

  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="form_content_block">
  <div class="clearfix"></div>
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">

      <div class="x_panel">
        <div class="y_title">
           <h2><i class="fa fa-edit"></i> Ficha de Alumno</h2>
           <div class="clearfix"></div>
        </div>

        <div class="x_content">

        <?php echo Form::open(['route' => 'dashboard.student.store', 'class' => 'form-horizontal form-label-left']); ?>


        <?php if(Session::has('message')): ?>
        <div class="alert alert-success alert-dismissible fade in" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
          <strong>¡Perfecto!</strong><?php echo e(Session::get('message')); ?>

        </div>
        <?php endif; ?>

        <div class="form-group">

          <div class="row">

            <div class="col-md-6 col-sm-6 col-xs-12">
               <label for="nombre">Nombre de participante</label>
               <input type="text" id="nombre" placeholder="Nombre" name="nombre"  class="form-control" value="<?php echo e(old('nombre')); ?>">
               <?php if($errors->has('nombre')): ?>
               <label for="nombre" generated="true" class="error"><?php echo e($errors->first('nombre')); ?></label>
               <?php endif; ?>
            </div>

            <div class="col-md-6 col-sm-6 col-xs-12">
               <label for="ape_pat">Apellido paterno</label>
               <input type="text" id="ape_pat" placeholder="Apellido paterno" name="ape_pat"  class="form-control" value="<?php echo e(old('ape_pat')); ?>">
               <?php if($errors->has('ape_pat')): ?>
               <label for="ape_pat" generated="true" class="error"><?php echo e($errors->first('ape_pat')); ?></label>
               <?php endif; ?>
            </div>

          </div>
        </div>

        <div class="form-group">

          <div class="row">

            <div class="col-md-6 col-sm-6 col-xs-12">
              <label for="ape_mat">Apellido materno</label>
              <input type="text" id="ape_mat" placeholder="Apellido materno" name="ape_mat"  class="form-control" value="<?php echo e(old('ape_mat')); ?>">
              <?php if($errors->has('ape_mat')): ?>
              <label for="ape_mat" generated="true" class="error"><?php echo e($errors->first('ape_mat')); ?></label>
              <?php endif; ?>
            </div>

            <div class="col-md-6 col-sm-6 col-xs-12">
              <label for="cod_doc_tip">Tipo de Documento</label>
              <select class="form-control" name="cod_doc_tip" id="cod_doc_tip" data-id-default="<?php echo e(old('cod_doc_tip')); ?>"><option value="">-- Seleccione el Tipo de Documento --</option></select>
              <?php if($errors->has('cod_doc_tip')): ?>
              <label for="cod_doc_tip" generated="true" class="error"><?php echo e($errors->first('cod_doc_tip')); ?></label>
              <?php endif; ?>
            </div>

          </div>

        </div>

        <div class="form-group">
          <div class="row">

            <div class="col-md-12 col-sm-12 col-xs-12">
              <label for="dni">Número de documento</label>
              <input type="text" id="num_doc" placeholder="Número de documento" name="num_doc"  class="form-control" value="<?php echo e(old('num_doc')); ?>">
              <?php if($errors->has('num_doc')): ?>
              <label for="num_doc" generated="true" class="error"><?php echo e($errors->first('num_doc')); ?></label>
              <?php endif; ?>
            </div>

          </div>
        </div>

        <div class="form-group">
          <div class="row">

            <div class="col-md-12 col-sm-12 col-xs-12">
              <label for="correo">Correo electrónico</label>
              <input type="text" id="correo" placeholder="Correo electrónico" name="correo"  class="form-control" value="<?php echo e(old('correo')); ?>">
              <?php if($errors->has('correo')): ?>
              <label for="correo" generated="true" class="error"><?php echo e($errors->first('correo')); ?></label>
              <?php endif; ?>
            </div>

          </div>
        </div>


        <div class="form-group">
          <div class="row">
              <div class="col-md-6 col-sm-6 col-xs-12">
                  <label for="cod_pais">País</label>
                  <select class="form-control" name="cod_pais" id="cod_pais" data-id-default="<?php echo e(old('cod_pais')); ?>"><option value="">-- Seleccione el País --</option></select>
                  <?php if($errors->has('cod_pais')): ?>
                  <label for="cod_pais" generated="true" class="error"><?php echo e($errors->first('cod_pais')); ?></label>
                  <?php endif; ?>
              </div>

              <div class="col-md-6 col-sm-6 col-xs-12">
                  <label for="cod_dpto">Departamento</label>
                  <select class="form-control" name="cod_dpto" id="cod_dpto" data-id-default="<?php echo e(old('cod_dpto')); ?>"><option value="">-- Seleccione el Departamento --</option></select>
                  <?php if($errors->has('cod_dpto')): ?>
                  <label for="cod_dpto" generated="true" class="error"><?php echo e($errors->first('cod_dpto')); ?></label>
                  <?php endif; ?>
              </div>
          </div>
        </div>


        <div class="form-group">
          <div class="row">

            <div class="col-md-6 col-sm-6 col-xs-12">
              <label for="cod_prov">Provincia</label>
              <select class="form-control" name="cod_prov" id="cod_prov" data-id-default="<?php echo e(old('cod_prov')); ?>"><option value="">-- Seleccione la provincia --</option></select>
              <?php if($errors->has('cod_prov')): ?>
              <label for="cod_prov" generated="true" class="error"><?php echo e($errors->first('cod_prov')); ?></label>
              <?php endif; ?>
            </div>

            <div class="col-md-6 col-sm-6 col-xs-12">
              <label for="cod_dist">Distrito</label>
              <select class="form-control" name="cod_dist" id="cod_dist" data-id-default="<?php echo e(old('cod_dist')); ?>"><option value="">-- Seleccione el distrito --</option></select>
              <?php if($errors->has('direccion')): ?>
              <label for="cod_dist" generated="true" class="error"><?php echo e($errors->first('cod_dist')); ?></label>
              <?php endif; ?>
            </div>

          </div>
        </div>

        <div class="form-group">

          <div class="row">

            <div class="col-md-12 col-sm-12 col-xs-12">
              <label for="direccion">Dirección</label>
              <input type="text" id="direccion" placeholder="Dirección" name="direccion"  class="form-control" value="<?php echo e(old('direccion')); ?>">
              <?php if($errors->has('direccion')): ?>
              <label for="direccion" generated="true" class="error"><?php echo e($errors->first('direccion')); ?></label>
              <?php endif; ?>
            </div>

          </div>

        </div>

        <div class="form-group">
          <div class="row">

            <div class="col-md-6 col-sm-6 col-xs-12">
              <label for="nom_corto">Fecha de nacimiento</label>
              <div class="date_content">
                <input type="text" id="fe_nacimiento" placeholder="Fecha de nacimiento" name="fe_nacimiento"  class="form-control form-control has-feedback-left calendar" value="<?php echo e(old('fe_nacimiento')); ?>">
                <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
              </div>
              <?php if($errors->has('direccion')): ?>
              <label for="fe_nacimiento" generated="true" class="error"><?php echo e($errors->first('fe_nacimiento')); ?></label>
              <?php endif; ?>
            </div>

            <div class="col-md-6 col-sm-6 col-xs-12">
              <label for="cod_sexo">Género</label>
              <?php echo e(Form::select('cod_sexo', array('' => '-- Seleccione el sexo --','1' => 'Masculino', '2' => 'Femenino'), old('cod_sexo'), ['class' => 'form-control'] )); ?>

              <?php if($errors->has('cod_sexo')): ?>
              <label for="cod_esp" generated="true" class="error"><?php echo e($errors->first('cod_sexo')); ?></label>
              <?php endif; ?>
            </div>

          </div>
        </div>

        <div class="form-group">
          <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
              <label for="num_tel_mobile">Teléfono celular</label>
              <input type="text" id="num_cellphone" placeholder="Teléfono celular" name="num_cellphone" class="form-control" value="<?php echo e(old('num_cellphone')); ?>">
              <?php if($errors->has('num_cellphone')): ?>
              <label for="num_cellphone" generated="true" class="error"><?php echo e($errors->first('num_cellphone')); ?></label>
              <?php endif; ?>
            </div>

            <div class="col-md-6 col-sm-6 col-xs-12">
              <label for="num_tel_fijo">Teléfono Fijo</label>
              <input type="text" id="num_phone" placeholder="Teléfono fijo" name="num_phone" class="form-control" value="<?php echo e(old('num_phone')); ?>">
              <?php if($errors->has('num_phone')): ?>
              <label for="num_phone" generated="true" class="error"><?php echo e($errors->first('num_phone')); ?></label>
              <?php endif; ?>
            </div>
          </div>
        </div>

        <div class="chkContent">
           <?php echo e(Form::checkbox('proteccion_datos', 1, false, ['class' => 'flat'])); ?>Acepto los <a href="#" title="términos y condiciones" target="_blank">términos y condiciones</a> y brindo mi consentimiento para el tratamiento de mis datos de carácter personal proporcionados en el presente formulario de inscripción al equipo de Doktuz, para que sean analizados, procesados, almacenados y transferidos, de tal manera que puedan brindarme todos los servicios que ofrecen de manera directa o a través de terceros. Si tienes alguna duda o sugerencia puedes escribirnos a <a href="#">contacto@info.com</a> y con gusto responderemos tus dudas o sugerencias.
           <?php if($errors->has('proteccion_datos')): ?>
           <label for="proteccion_datos" generated="true" class="error"><?php echo e($errors->first('proteccion_datos')); ?></label>
           <?php endif; ?>
        </div>

        <div class="ln_solid"></div>



        <div class="form-group btncontrol">
          <a href="<?php echo e(route('dashboard.student.index')); ?>" class="btn btn-5 btn-5a icon-return return"><span>Retornar</span></a>
          <button type="submit" class="btn btn-5 btn-5a icon-save save"><span>Guardar</span></button>
        </div>


        <?php echo Form::close(); ?>


        </div>

      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_js'); ?>
  <script src="<?php echo e(URL::asset('assets/js/app.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/js/app-students.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/js/app-document-type.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>