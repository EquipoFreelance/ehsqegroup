<!-- sidebar menu -->
<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
   <div class="menu_section">
      <div class="clear"></div>
      <ul class="nav side-menu">
         <li class="title">Menú principal</li>
         <!--<li><a href="<?php echo e(route('dashboard.inscription.index')); ?>"><i class="fa fa-tasks"></i> Reporte de Asistencias</a></li>-->
         <li><a href="<?php echo e(route('dashboard.students.report-card')); ?>"><i class="fa fa-tasks"></i> Reporte de Cursos</a></li>
         <!--<li><a href="<?php echo e(route('dashboard.inscription.index')); ?>"><i class="fa fa-tasks"></i> Reporte de Actividades</a></li>-->
         <!--<li><a href="<?php echo e(route('dashboard.inscription.index')); ?>"><i class="fa fa-tasks"></i> Encuesta</a></li>-->
      </ul>
   </div>
</div>
<!-- /sidebar menu -->
