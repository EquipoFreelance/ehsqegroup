

<?php $__env->startSection('content'); ?>
<div class="form_content_block">
  <div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">

    <div class="x_panel">

      <div class="y_title">
        <h2><i class="fa fa-edit"></i>Nuevo</h2>
        <div class="clearfix"></div>
      </div>

      <div class="x_content">
        <?php echo Form::open(['route' => 'dashboard.esp.store', 'class' => 'form-horizontal form-label-left']); ?>


        <?php if(Session::has('message')): ?>
        <div class="alert alert-success alert-dismissible fade in" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
          <strong>¡Perfecto!</strong><?php echo e(Session::get('message')); ?>

        </div>
        <?php endif; ?>

        <div class="form-group">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <label for="cod_mod">Modalidad</label>
            <?php echo e(Form::select('cod_mod', $modalidades, old('cod_mod'), ['class' => 'form-control'])); ?>

            <?php if($errors->has('cod_mod')): ?>
              <label for="cod_mod" generated="true" class="error"><?php echo e($errors->first('cod_mod')); ?></label>
            <?php endif; ?>
          </div>
        </div>

        <div class="form-group">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <label for="cod_esp_tipo">Tipo de especialización</label>
            <?php echo e(Form::select('cod_esp_tipo', $types, old('cod_esp_tipo'), ['class' => 'form-control'])); ?>

            <?php if($errors->has('cod_esp_tipo')): ?>
              <label for="cod_esp_tipo" generated="true" class="error"><?php echo e($errors->first('cod_esp_tipo')); ?></label>
            <?php endif; ?>
          </div>
        </div>

        <div class="form-group">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <label for="nom_esp_tipo">Nombre</label>
            <input type="text" id="nom_esp" placeholder="Nombre" name="nom_esp"  class="form-control" value="<?php echo e(old('nom_esp')); ?>">
            <?php if($errors->has('nom_esp')): ?>
            <label for="nom_esp" generated="true" class="error"><?php echo e($errors->first('nom_esp')); ?></label>
            <?php endif; ?>
          </div>
        </div>

        <div class="form-group">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <label for="nom_esp_tipo">Nombre corto</label>
            <input type="text" id="nom_corto" placeholder="Nombre corto" name="nom_corto"  class="form-control" value="<?php echo e(old('nom_corto')); ?>">
            <?php if($errors->has('nom_corto')): ?>
            <label for="nom_corto" generated="true" class="error"><?php echo e($errors->first('nom_corto')); ?></label>
            <?php endif; ?>
          </div>
        </div>

        <div class="form-group">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <label for="descripcion">Descripción</label>
            <textarea class="form-control" name="descripcion" placeholder="Descripción"><?php echo e(old('descripcion')); ?></textarea>
            <?php if($errors->has('descripcion')): ?>
            <label for="descripcion" generated="true" class="error"><?php echo e($errors->first('descripcion')); ?></label>
            <?php endif; ?>
          </div>
        </div>

        <div class="form-group">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <label for="activo">Estado</label>
            <?php echo e(Form::select('activo', ['1' => 'Activo','0' => 'No Activo'], old('activo'), ['class' => 'form-control'] )); ?>

            <?php if($errors->has('activo')): ?>
            <label for="activo" generated="true" class="error"><?php echo e($errors->first('activo')); ?></label>
            <?php endif; ?>
          </div>
        </div>

        <div class="ln_solid"></div>

        <div class="form-group btncontrol">
          <a href="<?php echo e(route('dashboard.esp.index')); ?>" class="btn btn-5 btn-5a icon-return return"><span>Retornar</span></a>
          <button type="submit" class="btn btn-5 btn-5a icon-save save"><span>Guardar</span></button>
        </div>

        <?php echo Form::close(); ?>

      </div>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>