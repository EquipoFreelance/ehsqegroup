

<?php $__env->startSection('content'); ?>
    <div class="form_content_block">

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">

                <div class="x_panel">

                    <div class="x_content">

                        <center>¡Muchas Gracias por Inscribirte!</center>

                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master_public', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>