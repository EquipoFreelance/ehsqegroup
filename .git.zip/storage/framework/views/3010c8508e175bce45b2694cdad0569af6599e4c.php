

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

Bienvenido: <?php echo e(Auth::user()->username); ?><br>

<ul>
  <li>Menu Principal</li>
  <li><a href="#">Crear Tipo Especialidades</a></li>
  <li><a href="#">Crear Especialidades</a></li>
</ul>

<h1>Listado de Tipo de Especialidades</h1>
  <?php foreach($esps_types as $esp_type): ?>
      <p>Tipo Especialidad: <?php echo e($esp_type->name); ?> con identificador: <?php echo e($esp_type->id); ?></p>
  <?php endforeach; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_internas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>