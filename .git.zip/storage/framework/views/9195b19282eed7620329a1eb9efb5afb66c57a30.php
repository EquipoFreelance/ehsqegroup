

<?php $__env->startSection('content'); ?>
  <div class="form_content_block">
    <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <br>
      <div class="x_panel">
        <div class="x_title">
          <h1 style="font-size: 18px">Nuevo</h1>
          <div class="clearfix"></div>
        </div>

        <div class="x_content">
        <?php echo Form::open(['route' => 'dashboard.sede.local.store', 'class' => 'form-horizontal form-label-left']); ?>


          <?php if(Session::has('message')): ?>
            <div class="alert alert-success alert-dismissible fade in" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
              <?php echo e(Session::get('message')); ?>

            </div>
          <?php endif; ?>

          <div class="form-group">
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <?php echo e(Form::label('cod_sede', 'Sede:')); ?>

                <?php echo e(Form::select('cod_sede', $sedes, old('cod_sede'), ['class' => 'form-control'] )); ?>

                <?php if($errors->has('cod_sede')): ?>
                  <label for="cod_sede" generated="true" class="error"><?php echo e($errors->first('cod_sede')); ?></label>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <?php echo e(Form::label('nom_local', 'Nombre del Local')); ?>

                <?php echo e(Form::text('nom_local', old('nom_local'), ['class' => 'form-control'] )); ?>

                <?php if($errors->has('nom_local')): ?>
                  <label for="nom_local" generated="true" class="error"><?php echo e($errors->first('nom_local')); ?></label>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <?php echo e(Form::label('direccion', 'Dirección')); ?>

                <?php echo e(Form::text('direccion', old('direccion'), ['class' => 'form-control'] )); ?>

                <?php if($errors->has('direccion')): ?>
                  <label for="nom_local" generated="true" class="error"><?php echo e($errors->first('direccion')); ?></label>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <label for="activo">Estado</label>
                <?php echo e(Form::select('activo', ['1' => 'Activo','0' => 'No Activo'], old('activo'), ['class' => 'form-control'] )); ?>

                <?php if($errors->has('activo')): ?>
                <label for="activo" generated="true" class="error"><?php echo e($errors->first('activo')); ?></label>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="ln_solid"></div>

          <div class="form-group btncontrol">
            <a href="<?php echo e(route('dashboard.sede.index')); ?>" class="btn btn-5 btn-5a icon-return return"><span>Retornar</span></a>
            <button type="submit" class="btn btn-5 btn-5a icon-save save"><span>Guardar</span></button>
          </div>

        <?php echo Form::close(); ?>

        </div>

      </div>
    </div>
  </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>