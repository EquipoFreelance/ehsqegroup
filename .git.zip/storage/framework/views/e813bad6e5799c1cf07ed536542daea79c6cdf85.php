

<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="page-title">
            <?php if(Session::has('message')): ?>
                <div class="alert alert-info">
                    <?php echo e(Session::get('message')); ?>

                </div>
            <?php endif; ?>
            <h1>Periodos académicos</h1>
            <p style="margin-top: 15px">Administrador Periodos académicos.</p>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <!-- INICIO TABLA FINAL -->
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">

                    <div class="x_title">
                        <a href="<?php echo e(route('dashboard.academic_period.create')); ?>" class="btn btn-5 btn-5a icon-add add"><span>Agregar</span></a>
                        <div class="clearfix"></div>
                    </div>

                    <div class="x_content">
                        <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                            <thead>
                            <tr>
                                <th>Id</th>
                                <th>Fecha de inicio</th>
                                <th>Fecha de finalización</th>
                                <th>Activo</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach($schedules as $schedule): ?>
                                <tr>
                                    <td><?php echo e($schedule->id); ?></td>
                                    <td><?php echo e($schedule->start_date); ?></td>
                                    <td><?php echo e($schedule->finish_date); ?></td>
                                    <td>
                                        <span class="label <?php if($schedule->active == '1'): ?> label-success <?php else: ?> label-danger <?php endif; ?> ">
                                            <?php if($schedule->active == '1'): ?> Activo <?php else: ?> No Activo <?php endif; ?>
                                        </span>
                                    </td>
                                    <td><a href="<?php echo e(route('dashboard.academic_period.edit', $schedule->id)); ?>" class="btn btn-5 btn-5a icon-edit edit"><span>Editar</span></a></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- FINAL TABLA FINAL -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>