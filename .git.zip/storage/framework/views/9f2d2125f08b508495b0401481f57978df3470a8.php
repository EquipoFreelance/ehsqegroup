<ul>
  <li>Menu Principal</li>
  <li><a href="/dashboard/tesp">Crear Tipo Especialidades</a></li>
  <li><a href="#">Crear Especialidades</a></li>
</ul>
