

<?php $__env->startSection('custom_css'); ?>

  <!-- CSS Plugin DatePicker Material -->
  <link href="<?php echo e(URL::asset('assets/js/datepicker_material/css/bootstrap-material-datetimepicker.css')); ?>" rel="stylesheet">

  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="form_content_block">
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <br>
      <div class="x_panel">
        <div class="y_title">
          <h2><i class="fa fa-edit"></i>Editar</h2>
          <div class="clearfix"></div>
        </div>

        <div class="x_content">
        <?php echo Form::model($grupo, [ 'method' => 'PUT', 'route' => ['dashboard.grupo.update', $grupo->id], 'class' => 'form-horizontal form-label-left' ]); ?>


          <?php if(Session::has('message')): ?>
            <div class="alert alert-success alert-dismissible fade in" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
              <strong>¡Perfecto!</strong><?php echo e(Session::get('message')); ?>

            </div>
          <?php endif; ?>

          <div class="form-group">
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <label for="cod_modalidad">Periódo académico:</label>
                <select name="id_academic_period" id="id_academic_period" class="form-control" data-id-default="<?php echo e($grupo->id_academic_period); ?>"></select>
                <?php if($errors->has('id_academic_period')): ?>
                  <label for="id_academic_period" generated="true" class="error"><?php echo e($errors->first('cod_modalidad')); ?></label>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="row">
              <div class="col-md-6 col-sm-6 col-xs-12">
                <label for="cod_modalidad">Modalidad:</label>
                <select name="cod_modalidad" id="cod_modalidad" class="form-control" data-id-default="<?php echo e($grupo->cod_modalidad); ?>"></select>
                <?php if($errors->has('cod_modalidad')): ?>
                  <label for="cod_modalidad" generated="true" class="error"><?php echo e($errors->first('cod_modalidad')); ?></label>
                <?php endif; ?>
              </div>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <label for="cod_esp_tipo">Tipo de Especialización:</label>
                <select name="cod_esp_tipo" id="cod_esp_tipo" class="form-control" data-id-default="<?php echo e($grupo->cod_esp_tipo); ?>"></select>
                <?php if($errors->has('cod_esp_tipo')): ?>
                  <label for="cod_esp_tipo" generated="true" class="error"><?php echo e($errors->first('cod_esp_tipo')); ?></label>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="row">
              <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::label('cod_esp', 'Especializacion:')); ?>

                <select name="cod_esp" id="cod_esp" class="form-control form-control" data-id-default="<?php echo e($grupo->cod_esp); ?>">
                  <option value="">-- Seleccione la especialización --</option>
                </select>
                <?php if($errors->has('cod_esp')): ?>
                  <label for="cod_esp" generated="true" class="error"><?php echo e($errors->first('cod_esp')); ?></label>
                <?php endif; ?>
              </div>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::label('cod_sede', 'Sede')); ?>

                <?php echo e(Form::select('cod_sede', $sedes, $grupo->cod_sede, ['class' => 'form-control'] )); ?>

                <?php if($errors->has('cod_sede')): ?>
                  <label for="cod_sede" generated="true" class="error"><?php echo e($errors->first('cod_sede')); ?></label>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <?php echo e(Form::label('nom_grupo', 'Nombre del grupo:')); ?>

                <?php echo e(Form::text('nom_grupo', $grupo->nom_grupo, ['class' => 'form-control'] )); ?>

                <?php if($errors->has('nom_grupo')): ?>
                  <label for="nom_grupo" generated="true" class="error"><?php echo e($errors->first('nom_grupo')); ?></label>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <?php echo e(Form::label('descripcion', 'Descripción:')); ?>

                <?php echo e(Form::textarea('descripcion', $grupo->descripcion, ['class' => 'form-control'] )); ?>

                <?php if($errors->has('descripcion')): ?>
                  <label for="descripcion" generated="true" class="error"><?php echo e($errors->first('descripcion')); ?></label>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="row">
              <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::label('fe_inicio', 'Fecha de inicio:')); ?>

                <?php echo e(Form::text('fe_inicio', $grupo->fe_inicio, ['class' => 'form-control'] )); ?>

                <?php if($errors->has('fe_inicio')): ?>
                  <label for="fe_inicio" generated="true" class="error"><?php echo e($errors->first('fe_inicio')); ?></label>
                <?php endif; ?>
              </div>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::label('fe_fin', 'Fecha de fin:')); ?>

                <?php echo e(Form::text('fe_fin', $grupo->fe_fin, ['class' => 'form-control'] )); ?>

                <?php if($errors->has('fe_fin')): ?>
                  <label for="fe_fin" generated="true" class="error"><?php echo e($errors->first('fe_fin')); ?></label>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="row">
              <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::label('num_min', 'Número mínimo:')); ?>

                <?php echo e(Form::text('num_min', $grupo->num_min, ['class' => 'form-control'] )); ?>

                <?php if($errors->has('num_min')): ?>
                  <label for="num_min" generated="true" class="error"><?php echo e($errors->first('num_min')); ?></label>
                <?php endif; ?>
              </div>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <?php echo e(Form::label('num_max', 'Número máximo:')); ?>

                <?php echo e(Form::text('num_max', $grupo->num_max, ['class' => 'form-control'] )); ?>

                <?php if($errors->has('num_max')): ?>
                  <label for="num_max" generated="true" class="error"><?php echo e($errors->first('num_max')); ?></label>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <label for="activo">Estado</label>
                <?php echo e(Form::select('activo', ['1' => 'Activo','0' => 'No Activo'], $grupo->activo, ['class' => 'form-control'] )); ?>

                <?php if($errors->has('activo')): ?>
                  <label for="activo" generated="true" class="error"><?php echo e($errors->first('activo')); ?></label>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="ln_solid"></div>

          <div class="form-group btncontrol">
            <a href="<?php echo e(route('dashboard.grupo.index')); ?>" class="btn btn-5 btn-5a icon-return return"><span>Retornar</span></a>
            <?php echo e(Form::button('<span>Guardar</span>', array('class' => 'btn btn-5 btn-5a icon-save save', 'type' => 'submit'))); ?>

          </div>

        <?php echo Form::close(); ?>


        <?php echo Form::open([
                    'method' => 'DELETE',
                    'route' => ['dashboard.grupo.destroy', $grupo->id]
                ]); ?>

            <button type="submit" class="btn btn-danger cancel_btn">Eliminar</button>
        <?php echo Form::close(); ?>

        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_js'); ?>
  <script src="<?php echo e(URL::asset('assets/js/app.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/js/app-academic-period.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('assets/js/app-group.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>