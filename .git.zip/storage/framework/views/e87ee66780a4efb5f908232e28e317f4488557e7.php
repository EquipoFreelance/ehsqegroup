

<?php $__env->startSection('title', 'Dashboard - Secretaria Académica Módulos'); ?>

<?php $__env->startSection('sidebar_menu'); ?>
<?php echo $__env->make('dashboard.dashboard_sa_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="clearfix"></div>
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <br>
      <div class="x_panel">
        <div class="x_title">
          <h1 style="font-size: 18px">Nuevo Personal <small> (En este interior usted podrá ingresar una nueva Especialización, editar los datos ingresados)</small></h1>
          <div class="clearfix"></div>
        </div>
        <br>

        <?php echo Form::open(['route' => 'dashboard.persona.store', 'class' => 'form-horizontal form-label-left']); ?>


        <?php if(Session::has('message')): ?>
        <div class="alert alert-success alert-dismissible fade in" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
          <strong>¡Perfecto!</strong><?php echo e(Session::get('message')); ?>

        </div>
        <?php endif; ?>

        <div class="form-group">
          <label class="control-label col-md-4 col-sm-4 col-xs-12" for="cod_personal_cargo_tipo">Tipo de personal</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <?php echo e(Form::select('cod_personal_cargo_tipo', $personal_cargo, old('cod_personal_cargo_tipo'), ['class' => 'form-control'] )); ?>

            <?php if($errors->has('cod_personal_cargo_tipo')): ?>
            <label for="cod_personal_cargo_tipo" generated="true" class="error"><?php echo e($errors->first('cod_personal_cargo_tipo')); ?></label>
            <?php endif; ?>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-4 col-sm-4 col-xs-12" for="cod_doc_tip">Tipo de Documento</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <?php echo e(Form::select('cod_doc_tip', array('1' => 'DNI', '2' => 'Carnet de Extranjeria'), old('cod_doc_tip'), ['class' => 'form-control'] )); ?>

            <?php if($errors->has('cod_doc_tip')): ?>
            <label for="cod_doc_tip" generated="true" class="error"><?php echo e($errors->first('cod_doc_tip')); ?></label>
            <?php endif; ?>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-4 col-sm-4 col-xs-12" for="dni">DNI</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="num_doc" placeholder="Número de documento" name="num_doc"  class="form-control" value="<?php echo e(old('num_doc')); ?>">
            <?php if($errors->has('num_doc')): ?>
            <label for="num_doc" generated="true" class="error"><?php echo e($errors->first('num_doc')); ?></label>
            <?php endif; ?>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-4 col-sm-4 col-xs-12" for="nombre">Nombre</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="nombre" placeholder="Nombre" name="nombre"  class="form-control" value="<?php echo e(old('nombre')); ?>">
            <?php if($errors->has('nombre')): ?>
            <label for="nombre" generated="true" class="error"><?php echo e($errors->first('nombre')); ?></label>
            <?php endif; ?>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-4 col-sm-4 col-xs-12" for="nom_corto">Apellido paterno</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="ape_pat" placeholder="Apellido paterno" name="ape_pat"  class="form-control" value="<?php echo e(old('ape_pat')); ?>">
            <?php if($errors->has('ape_pat')): ?>
            <label for="ape_pat" generated="true" class="error"><?php echo e($errors->first('ape_pat')); ?></label>
            <?php endif; ?>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-4 col-sm-4 col-xs-12" for="nom_corto">Apellido materno</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="ape_mat" placeholder="Apellido materno" name="ape_mat"  class="form-control" value="<?php echo e(old('ape_mat')); ?>">
            <?php if($errors->has('ape_mat')): ?>
            <label for="ape_mat" generated="true" class="error"><?php echo e($errors->first('ape_mat')); ?></label>
            <?php endif; ?>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-4 col-sm-4 col-xs-12" for="nom_corto">Dirección</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="direccion" placeholder="Dirección" name="direccion"  class="form-control" value="<?php echo e(old('direccion')); ?>">
            <?php if($errors->has('direccion')): ?>
            <label for="direccion" generated="true" class="error"><?php echo e($errors->first('direccion')); ?></label>
            <?php endif; ?>
          </div>
        </div>

        <div class="form-group">
          <label class="control-label col-md-4 col-sm-4 col-xs-12" for="nom_corto">Fecha de nacimiento</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="fe_nacimiento" placeholder="Fecha de nacimiento" name="fe_nacimiento"  class="form-control" value="<?php echo e(old('fe_nacimiento')); ?>">
            <?php if($errors->has('direccion')): ?>
            <label for="fe_nacimiento" generated="true" class="error"><?php echo e($errors->first('fe_nacimiento')); ?></label>
            <?php endif; ?>
          </div>
        </div>


        <div class="form-group">
          <label class="control-label col-md-4 col-sm-4 col-xs-12" for="cod_sexo">Género</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <?php echo e(Form::select('cod_sexo', array('1' => 'Masculino', '2' => 'Femenino'), old('cod_sexo'), ['class' => 'form-control'] )); ?>

            <?php if($errors->has('cod_sexo')): ?>
            <label for="cod_esp" generated="true" class="error"><?php echo e($errors->first('cod_sexo')); ?></label>
            <?php endif; ?>
          </div>
        </div>


        <div class="form-group">
          <label class="control-label col-md-4 col-sm-4 col-xs-12" for="activo">Estado</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <?php echo e(Form::select('activo', ['1' => 'Activo','0' => 'No Activo'], old('activo'), ['class' => 'form-control'] )); ?>

            <?php if($errors->has('activo')): ?>
            <label for="activo" generated="true" class="error"><?php echo e($errors->first('activo')); ?></label>
            <?php endif; ?>
          </div>
        </div>

        <div class="ln_solid"></div>
        <div class="form-group">
          <label class="control-label col-md-4 col-sm-4 col-xs-12"></label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="form-group btncontrol">
              <a href="<?php echo e(route('dashboard.modulo.index')); ?>" class="btn btn-default">Retornar</a>
              <!--<a href="<?php echo e(route('dashboard.tesp.index')); ?>" class="btn btn-danger cancel_btn">Cancelar</a>-->
              <button type="submit" class="btn btn-success">Guardar</button>
            </div>
          </div>
        </div>
        <?php echo Form::close(); ?>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_internas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>