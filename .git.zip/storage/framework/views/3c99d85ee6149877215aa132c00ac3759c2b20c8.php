

<?php $__env->startSection('content'); ?>
    <div class="form_content_block">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">

                <div class="x_panel">

                    <div class="y_title">
                        <h2><i class="fa fa-edit"></i>Editar</h2>
                        <div class="clearfix"></div>
                    </div>

                    <div class="x_content">

                        <?php echo Form::model($schedule, [ 'method' => 'PUT', 'route' => ['dashboard.academic_period.update', $schedule->id], 'class' => 'form-horizontal form-label-left' ]); ?>


                        <?php if(Session::has('message')): ?>
                            <div class="alert alert-success alert-dismissible fade in" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                                <?php echo e(Session::get('message')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <label for="start_date">Fecha de Inicio</label>
                                    <input type="text" id="start_date" placeholder="Fecha de Inicio" name="start_date"  class="form-control" value="<?php echo e($schedule->start_date); ?>">
                                    <?php if($errors->has('start_date')): ?>
                                        <label for="start_date" generated="true" class="error"><?php echo e($errors->first('start_date')); ?></label>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <label for="finish_date">Fecha de Finalización</label>
                                    <input type="text" id="finish_date" placeholder="Fecha de Finalización" name="finish_date"  class="form-control" value="<?php echo e($schedule->finish_date); ?>">
                                    <?php if($errors->has('finish_date')): ?>
                                        <label for="finish_date" generated="true" class="error"><?php echo e($errors->first('finish_date')); ?></label>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="ln_solid"></div>

                        <div class="form-group btncontrol">
                            <a href="<?php echo e(route('dashboard.academic_period.index')); ?>" class="btn btn-5 btn-5a icon-return return"><span>Retornar</span></a>
                            <button type="submit" class="btn btn-5 btn-5a icon-save save"><span>Guardar</span></button>
                        </div>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('custom_js'); ?>
            <script src="<?php echo e(URL::asset('assets/js/app-academic-period.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>