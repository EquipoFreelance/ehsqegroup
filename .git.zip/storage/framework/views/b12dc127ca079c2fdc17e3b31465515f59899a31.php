<img src="https://doktuz.com/icon_usuarios/b9c55ab7d80b70440fcceb2c69adea12.0ae92886072bdc4c1585ddc77e4eb7de.png" width="50" height="50">
<p>Bienvenido: <?php echo e(Auth::user()->username); ?></p>
