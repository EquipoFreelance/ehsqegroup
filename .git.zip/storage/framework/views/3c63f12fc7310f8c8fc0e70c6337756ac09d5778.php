

<?php $__env->startSection('title', Auth::user()->role->nom_role  ); ?>

<?php $__env->startSection('sidebar_menu'); ?>
  <?php echo $__env->make('dashboard.menus.' . Auth::user()->role->menu , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="">
  <div class="page-title">
    <?php if(Session::has('message')): ?>
        <div class="alert alert-info">
            <?php echo e(Session::get('message')); ?>

        </div>
    <?php endif; ?>
    <h1>Talleres</h1>
    <p style="margin-top: 15px">Administrador de Talleres.</p>
  </div>
  <div class="clearfix"></div>
  <div class="row">
    <!-- INICIO TABLA FINAL -->
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_panel">

        <div class="x_title">
            <a href="<?php echo e(route('dashboard.taller.create')); ?>" class="btn btn-5 btn-5a icon-add add"><span>Agregar</span></a>
            <div class="clearfix"></div>
        </div>

        <div class="x_content">
          <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
            <thead>
              <tr>
                <th>Código</th>
                <th>Taller</th>
                <th>Estado</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($talleres as $taller): ?>
                  <tr data-id="<?php echo e($taller->id); ?>">
                    <td class="data-cod" data-cod="<?php echo e($taller->id); ?>"><?php echo e($taller->id); ?></td>
                    <td class="data-tipo" data-tipo="<?php echo e($taller->nom_taller); ?>"><?php echo e($taller->nom_taller); ?></td>
                    <td class="data-acti" data-acti="<?php echo e($taller->activo); ?>">
                      <span class="label <?php if($taller->activo == '1'): ?> label-success <?php else: ?> label-danger <?php endif; ?> ">
                        <?php if($taller->activo == '1'): ?> Activo <?php else: ?> No Activo <?php endif; ?>
                      </span>
                    </td>
                    <td><a href="<?php echo e(route('dashboard.taller.edit', $taller->id)); ?>" class="btn btn-5 btn-5a icon-edit edit"><span>Editar</span></a></td>
                  </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <!-- FINAL TABLA FINAL -->
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>