

<?php $__env->startSection('content'); ?>
<div class="">
  <div class="page-title">
    <?php if(Session::has('message')): ?>
        <div class="alert alert-info">
            <?php echo e(Session::get('message')); ?>

        </div>
    <?php endif; ?>
    <h1>Grupos</h1>
    <p style="margin-top: 15px">Administrador de Grupos.</p>
  </div>

  <div class="row">
    <!-- INICIO TABLA FINAL -->
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_panel">

        <div class="x_title">
          <a href="<?php echo e(route('dashboard.grupo.create')); ?>" class="btn btn-5 btn-5a icon-add add"><span>Agregar</span></a>
          <div class="clearfix"></div>
        </div>

        <div class="ln_solid"></div>
        <div class="x_content">
          <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
            <thead>
              <tr>
                <th>Código</th>
                <th>Nombre</th>
                <th colspan="2"></th>
                <th>Estado</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($grupos as $grupo): ?>
                  <tr>
                    <td><?php echo e($grupo->id); ?></td>
                    <td><?php echo e($grupo->sede->nom_local); ?> - <?php echo e($grupo->nom_grupo); ?></td>
                    <td><a href="<?php echo e(route('dashboard.academic_schedule.horario.group', $grupo->id)); ?>" class="btn btn-5 btn-5a icon-add add"><span>Horario Disponible</span></a></td>
                    <td><a href="<?php echo e(route('dashboard.grupo.students.list', $grupo->id)); ?>" class="btn btn-5 btn-5a icon-return return"><span>Alumnos</span></a></td>
                    <td>
                      <span class="label <?php if($grupo->activo == '1'): ?> label-success <?php else: ?> label-danger <?php endif; ?> ">
                        <?php if($grupo->activo == '1'): ?> Activo <?php else: ?> No Activo <?php endif; ?>
                      </span>
                    </td>
                    <td><a href="<?php echo e(route('dashboard.grupo.edit', $grupo->id)); ?>" class="btn btn-5 btn-5a icon-edit edit"><span>Editar</span></a>
                  </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <!-- FINAL TABLA FINAL -->
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>