

<?php $__env->startSection('title', Auth::user()->role->nom_role  ); ?>

<?php $__env->startSection('sidebar_menu'); ?>
  <?php echo $__env->make('dashboard.menus.' . Auth::user()->role->menu , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  Datos Estádisticos
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>