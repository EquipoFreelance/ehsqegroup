

<?php $__env->startSection('title', 'Dashboard Secretaria Académica - Tipo de Especialidades'); ?>

<?php $__env->startSection('content'); ?>

  <?php echo $__env->make('dashboard.dash_welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <?php echo $__env->make('dashboard.sa_admin_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <a href="#">Retornar</a><br>

  <h1>Crear Tipo de Especialización</h1><br>

  <form action="<?php echo e(url('/dashboard/tesp/')); ?>" method="POST">

    <?php echo csrf_field(); ?>


    <input type="text" name="nom_esp_tipo"  value="<?php echo e(old('nom_esp_tipo')); ?>" >
    <?php if($errors->has('nom_esp_tipo')): ?>
        <span class="help-block">
            <strong><?php echo e($errors->first('nom_esp_tipo')); ?></strong>
        </span>
    <?php endif; ?>

    <br>

    <select name="activo" id="activo">
      <option value="1" <?php echo e((old('activo') == 1 ? "selected":"")); ?>>Activo</option>
      <option value="0" <?php echo e((old('activo') == 0 ? "selected":"")); ?>>No Activo</option>
    </select>
    <?php if($errors->has('activo')): ?>
        <span class="help-block">
            <strong><?php echo e($errors->first('activo')); ?></strong>
        </span>
    <?php endif; ?>

    <br>
    <button type="submit">Crear</button>
  </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_internas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>