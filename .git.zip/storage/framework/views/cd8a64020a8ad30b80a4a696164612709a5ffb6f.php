

<?php $__env->startSection('title', 'Dashboard Secretaria Académica - Tipo de Especialidades'); ?>

<?php $__env->startSection('content'); ?>

  <?php echo $__env->make('dashboard.dash_welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <?php echo $__env->make('dashboard.dash_2_menu_main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <h1>Listado de Tipo de Especialidades</h1>
  <?php foreach($esps_types as $esp_type): ?>
      <p>Tipo Especialidad: <?php echo e($esp_type->name); ?> con identificador: <?php echo e($esp_type->id); ?></p>
  <?php endforeach; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_internas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>