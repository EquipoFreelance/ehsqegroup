

<?php $__env->startSection('title', 'Dashboard - Secretaria Académica'); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('dashboard.dash_welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('dashboard.sa_admin_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_internas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>