

<?php $__env->startSection('sidebar_menu'); ?>
  <?php echo $__env->make('dashboard.menus.' . Auth::user()->role->menu , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="">
  <div class="page-title">
    <?php if(Session::has('message')): ?>
        <div class="alert alert-info">
            <?php echo e(Session::get('message')); ?>

        </div>
    <?php endif; ?>
    <h1>Tipo de especializaciones</h1>
    <p style="margin-top: 15px">Administrador de Tipo de especializaciones.</p>
  </div>
  <div class="clearfix"></div>
  <div class="row">
    <!-- INICIO TABLA FINAL -->
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_panel">

        <div class="x_title">
          <a href="<?php echo e(route('dashboard.tesp.create')); ?>" class="btn btn-5 btn-5a icon-add add"><span>Agregar</span></a>
          <div class="clearfix"></div>
        </div>

        <div class="x_content">
          <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
            <thead>
              <tr>
                <th>Código</th>
                <th>Tipo Especialización</th>
                <th>Estado</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($esps_types as $esp_type): ?>
                  <tr>
                    <td><?php echo e($esp_type->id); ?></td>
                    <td><?php echo e($esp_type->nom_esp_tipo); ?></td>
                    <td>
                      <span class="label <?php if($esp_type->activo == '1'): ?> label-success <?php else: ?> label-danger <?php endif; ?> ">
                        <?php if($esp_type->activo == '1'): ?> Activo <?php else: ?> No Activo <?php endif; ?>
                      </span>
                    </td>
                    <td><a href="<?php echo e(route('dashboard.tesp.edit', $esp_type->id)); ?>" class="btn btn-5 btn-5a icon-edit edit"><span>Editar</span></a>
                  </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <!-- FINAL TABLA FINAL -->
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>