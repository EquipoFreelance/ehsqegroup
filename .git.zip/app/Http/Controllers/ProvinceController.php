<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\Province;

class ProvinceController extends Controller
{
  public function index($croloncho)
  {
    //return $croloncho;
    //return $provinces = Province::all()->toJson();
  }

}
