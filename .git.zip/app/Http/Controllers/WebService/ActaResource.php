<?php
/**
 * Created by PhpStorm.
 * User: JUAN
 * Date: 05/06/2017
 * Time: 03:56 PM
 */

namespace App\Http\Controllers\WebService;

use App\Http\Controllers\Controller;

use App\Repositories\Eloquents\ActaRepository;

use App\Repositories\Eloquents\EnrollmentRepository;
use App\Repositories\Eloquents\EspecializationRepository;
use App\Repositories\Eloquents\GroupRepository;
use App\Repositories\Eloquents\HoraryRepository;
use App\Repositories\Eloquents\ModuleRepository;
use App\Repositories\Eloquents\PersonRepository;
use App\Repositories\Eloquents\TeacherRepository;
use Illuminate\Http\Request;

class ActaResource extends Controller
{
    private $r_acta;
    private $r_esp;
    private $r_group;
    private $r_horary;
    private $r_module;
    private $r_teacher;
    private $r_person;
    private $r_enrollment;

    public function __construct(
        ActaRepository $r_acta,
        EspecializationRepository $r_esp,
        GroupRepository $r_group,
        HoraryRepository $r_horary,
        ModuleRepository $r_module,
        TeacherRepository $r_teacher,
        PersonRepository $r_person,
        EnrollmentRepository $r_enrollment

    )
    {
            $this->r_acta       = $r_acta;
            $this->r_esp        = $r_esp;
            $this->r_group      = $r_group;
            $this->r_horary     = $r_horary;
            $this->r_module     = $r_module;
            $this->r_teacher    = $r_teacher;
            $this->r_person     = $r_person;
            $this->r_enrollment = $r_enrollment;
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(Request $request){

        if( $request->get("id_group") ){

            $group = $this->r_group->getById($request->get("id_group"));

            /* Horaries */
            $horary = $this->r_horary->getIdByGroup($request->get("id_group"));

            if($horary->monday){
                $day_week = $this->r_horary->getDayWeek(0);
            } else if($horary->sunday){
                $day_week = $this->r_horary->getDayWeek(1);
            } else if($horary->tuesday){
                $day_week = $this->r_horary->getDayWeek(2);
            } else if($horary->wednesday){
                $day_week = $this->r_horary->getDayWeek(3);
            } else if($horary->thursday){
                $day_week = $this->r_horary->getDayWeek(4);
            } else if($horary->friday){
                $day_week = $this->r_horary->getDayWeek(5);
            } else if($horary->saturday){
                $day_week = $this->r_horary->getDayWeek(6);
            }

            /* Modules */
            $modules = $this->r_module->getModuleByIdEspecialization($group->especializacion->id);
            $ar_modules = array();
            foreach ($modules as $module) {

                $teacher = $this->r_teacher->getById($this->r_horary->getIdByModule($module->id)->cod_docente);

                $person = $this->r_person->getById($teacher->cod_persona);

                $ar_modules[] = array(
                                        "id"         => $module->id,
                                        "name"       => $module->nom_corto,
                                        "name_corto" => $module->nom_corto,
                                        "teacher"    => $person->nombre." ".$person->ape_pat." ".$person->ape_mat,
                                        "date"       => "",
                                );
            }


            /* Group Enrollment */

            $g_enrollments  = $group->group_enrollment;
            $ar_enrollments = array();

            foreach ($g_enrollments as $g_e) {


                $find_enrollment = $this->r_enrollment->getById($g_e->id_enrollment);

                $person = $this->r_person->getById($find_enrollment->student['cod_persona']);

                $ar_enrollments[] = array(
                    "order"     => $g_e->id,
                    "code"      => $g_e->id_enrollment,
                    "firstname" => $person->nombre,
                    "lastname"  => $person->ape_pat." ".$person->ape_mat,
                    "notes"     => array(
                        "id"   => "001",
                        "note" => array("01","02", "03", "04", "05"),
                        "prom_mod"       => "12",
                        "prom_pro_imp"   => "12",
                        "prom_pro_final" => "12.5"
                    )
                );

            }



            return response()->json(
                [
                    "response" => array(
                        "header" => array(
                            "especialization" => $group->especializacion->nom_esp,
                            "place"           => $group->sede->nom_local,
                            "schedule"        => $day_week." ".$horary->h_inicio." ".$horary->h_fin,
                            "duration"        => "Del ".$horary->fec_inicio." al ".$horary->fec_fin,
                            "observation"     => ""
                        ),
                        "body" => array(
                            "header" => array(
                                "group_count_esp" => array(
                                    "01",
                                    "02",
                                    "03",
                                    "04",
                                    "05",
                                    "06",
                                    "07",
                                    "08"
                                )
                            ),
                            "modules" => $ar_modules,
                            "data"    => $ar_enrollments
                        )
                    ),
                ], 200 );

        }

    }

}