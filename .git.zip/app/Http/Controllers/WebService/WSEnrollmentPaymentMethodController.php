<?php

namespace App\Http\Controllers\WebService;

use App\Repositories\Eloquents\EnrollmentPMRepository;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;


class WSEnrollmentPaymentMethodController extends Controller
{



}
