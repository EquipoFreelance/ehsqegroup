<?php
/**
 * Created by PhpStorm.
 * User: JUAN
 * Date: 26/01/2017
 * Time: 11:34 PM
 */

namespace App\Http\Controllers;

class ReportCardResource extends Controller
{

}