<?php

namespace App\Http\Controllers\WebService;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests;
use Carbon\Carbon;
use Auth;
use App\Models\GroupStudent;

class WSStudentController extends Controller
{

    

}
