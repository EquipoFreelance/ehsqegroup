<?php

/**
 * Created by PhpStorm.
 * User: JUAN
 * Date: 23/10/2016
 * Time: 10:55 PM
 */
/*class PaymentDetail
{

}*/