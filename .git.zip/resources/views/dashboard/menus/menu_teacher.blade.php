<!-- sidebar menu -->
<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
   <div class="menu_section">
      <div class="clear"></div>
      <ul class="nav side-menu">
         <li class="title">Menú principal</li>
         <!--<li><a href="{{ route('dashboard.teacher.assistance.index') }}"><i class="fa fa-tasks"></i> Asistencia de Alumnos</a></li>-->
         <li><a href="{{ route('dashboard.teacher.report-card.index') }}"><i class="fa fa-tasks"></i> Ingresos de Notas</a></li>
         <!--<li><a href="{{ route('teacher.academic_schedule.index') }}"><i class="fa fa-tasks"></i> Horarios</a></li>-->
      </ul>
   </div>
</div>
<!-- /sidebar menu -->
