<!-- sidebar menu -->
<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
   <div class="menu_section">
      <div class="clear"></div>
      <ul class="nav side-menu">
         <li class="title">Menú principal</li>
         <li><a href="{{ route('dashboard.inscription.index') }}"><i class="fa fa-tasks"></i> Inscripciones Realizadas</a></li>
      </ul>
   </div>
</div>
<!-- /sidebar menu -->
