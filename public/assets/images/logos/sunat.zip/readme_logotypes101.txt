This file is downloaded from logotypes101.com, all logos on the website are available for free and may not be resold. 

Credits to original creators. Let us know how we can serve you better @ logotypes101.com

Visit http://www.logotypes101.com
